#ifndef PGMIO_H_
#define PGMIO_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// These 3 variables below are the ONLY variables that need to be declared before the system runs.

#define  IMHeight 64 // max 1273 min 2
#define  IMWidth 64 // max 1300 min 2
#define numberOfWorkers 12 // Min: 2 Max: 12


// (imageHeight / numberOfWorkers)
#define workerHeight (IMHeight / numberOfWorkers)
// (imageHeight % numberOfWorkers)
#define lastWorkerHeight (IMHeight % numberOfWorkers) + workerHeight

// (((imageHeight / numberOfWorkers) * imageWidth) / 8) ADD One for excess.
#define sizeOfWorkerArray (((IMHeight / numberOfWorkers) * IMWidth) / 8) + 1
// (((imageHeight % numberOfWorkers) * imageWidth) /8)  WILL be at least one always.
#define sizeOfLastWorkerArray ((((IMHeight % numberOfWorkers) * IMWidth) / 8) + 1) + sizeOfWorkerArray

#define ghostRowSize (IMWidth/8)+1


int _writepgm(unsigned char x[], int height, int width, char fname[]);
int _readpgm(unsigned char x[], int height, int width, char fname[]);

int _openinpgm(char fname[], int width, int height);
int _readinline(unsigned char line[], int width);
int _closeinpgm();

int _openoutpgm(char fname[], int width, int height);
int _writeoutline(unsigned char line[], int width);
int _closeoutpgm();

#endif /*PGMIO_H_*/
